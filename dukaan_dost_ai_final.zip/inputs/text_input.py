"""Normalize typed shopkeeper instructions."""
